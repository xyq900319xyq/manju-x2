---
name: moyin-creator-debugging
description: "Diagnose and fix issues in the 魔因漫创 (moyin-creator) Electron app — asar extraction, API routing, reference image pipeline, and code injection."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [windows]
metadata:
  hermes:
    tags: [moyin-creator, electron, asar, debugging, image-generation, chuangwei]
    related_skills: [systematic-debugging, node-inspect-debugger]
---

# 魔因漫创 (moyin-creator) Debugging

## Overview

魔因漫创 is an Electron + Vite app for AI-powered comic/animation production. Its frontend is a single large renderer bundle (`index-BiEM7W1o.js`, ~7MB) and its main process is `index.cjs`. All business logic lives in the renderer bundle. Debugging involves extracting and patching `app.asar`, then re-deploying.

## When to Use

- Image generation fails or produces wrong results (missing characters, timeouts, blank outputs)
- Need to trace what data the app sends to its API
- API routing is wrong for a specific proxy/provider
- Reference images are not being picked up by the generation API
- Need to inject logging or modify behavior without source code

## App Architecture

| Layer | Location | Role |
|-------|----------|------|
| Main process | `out/main/index.cjs` (~164KB) | IPC handlers, image host upload, task records |
| Renderer bundle | `out/renderer/assets/index-BiEM7W1o.js` (~7.2MB) | ALL business logic, API calls, UI, state management |
| AI worker | `out/renderer/assets/ai-worker-CNEoMg1t.js` | Background AI task execution |

### Installation Path

```
D:\魔因\moyin-creator\resources\app.asar
```

### Data Paths

| Data | Path |
|------|------|
| User data root | `%APPDATA%\Roaming\魔因漫创-profiles\default-<hash>\` |
| Project store | `workspace-data/projects/moyin-project-store.json` |
| Character library | `workspace-data/projects/moyin-character-library.json` |
| Project files | `workspace-data/projects/_p/<project-id>/` |
| Runtime DB | `studio-run/runtime.db` (SQLite, WAL mode) |
| Media files | `workspace-data/media/characters/`, `scenes/` |
| API config | Zustand persist (localStorage/IndexedDB) |

Project-level files: `sclass.json`, `scenes.json`, `characters.json`, `script.json`, `director.json`, `media.json`

## Working with app.asar

### Extract a single file
```bash
cd /tmp && npm install asar
node -e "
const asar = require('./node_modules/asar');
const content = asar.extractFile('D:/魔因/moyin-creator/resources/app.asar', 'out/renderer/assets/index-BiEM7W1o.js').toString();
require('fs').writeFileSync('/tmp/renderer.js', content);
"
```

### Extract and repack with modifications
```bash
node -e "
const asar = require('./node_modules/asar');
const fs = require('fs');
// Extract
asar.extractAll(srcAsar, tmpDir);
// Replace modified file
fs.copyFileSync(patchedFile, tmpDir + '/out/renderer/assets/index-BiEM7W1o.js');
// Repack
asar.createPackage(tmpDir, destAsar);
"
```

### Deploy
```bash
# Backup
cp app.asar app.asar.bak_$(date +%Y%m%d_%H%M%S)
# Replace
cp app.asar.new app.asar
# Restart (kill first)
ps aux | grep moyin-creator | awk '{print $2}' | xargs -r kill
```

## Key Code Locations

### Image Generation API (`submitGridImageRequest`)

The central function for all grid/board/nine-grid image generation. Located in the renderer bundle. Key routing logic:

```
apiFormat === "openai_chat"    → submitViaChatCompletions (NOT for chuangwei)
apiFormat === "kling_image"    → submitViaKlingImages
chuangwei.cyou proxy detected  → POST /api/ai/image with apiKey in body
default                         → OpenAPI /v1/images/generations with Bearer auth
```

**Timeout**: `submitTimeoutMs = isMemefastGptImage2Model(model) ? 12e4 : 18e4`
**Retry**: 3 attempts, 3s base delay, 429 retry enabled

### Chuangwei Proxy Routing (critical section)

When `isChuangweiProxy = /chuangwei\.cyou/i.test(baseUrl)`:
- **Endpoint**: `${normalizedBase}/api/ai/image`
- **Auth**: `apiKey` in JSON body (NOT Bearer header)
- **Body format**: `{ prompt, negativePrompt, aspectRatio, apiKey, provider: "memefast", referenceImages }`
- **Response**: `{ imageUrl, taskId, status }` — if taskId present, poll `/api/ai/task/{taskId}`
- **Polling**: Up to 90 attempts, 2s interval

### Reference Image Pipeline

The full chain from character data to API:

```
1. collectCharacterRefs(characterIds, characters, options)
   └─ getCharacterPrimaryImage(char) → views[0].imageUrl || thumbnailUrl
   └─ buildAutoImageRef({ url, purpose: "character_ref" })

2. collectAllRefs(group, scenes, characters, ...)
   └─ pushUniqueRefs(charRefs, sceneRefs, manualRefs, ...)
   └─ Returns { images: taggedImages[], videos, audios }

3. Caller builds referenceImages:
   referenceImages: promptResult.refs.images.map(ref => ref.httpUrl || ref.localUrl).filter(Boolean)

4. submitGridImageRequest({ referenceImages, ... })
   └─ requestBody.image_urls = referenceImages
   └─ Sends to API
```

### buildAutoImageRef — the URL classification
```javascript
function buildAutoImageRef(params) {
  return {
    localUrl: normalizedUrl,                              // always set
    httpUrl: isRemoteLikeAssetUrl(normalizedUrl) ? normalizedUrl : null,  // only for http(s):// and asset://
  };
}
function isRemoteLikeAssetUrl(url) {
  return /^https?:\/\//i.test(url) || /^asset:\/\//i.test(url);
}
```

**Key pitfall**: `local-image://` URLs get `httpUrl = null`. When the caller uses `ref.httpUrl || ref.localUrl`, the `local-image://` URL is passed verbatim to the API. Remote proxies (chuangwei.cyou) cannot resolve these.

## Common Issues

### 1. Nine-grid / storyboard images missing characters

**Root cause**: Character reference images are `local-image://` format. The proxy API (chuangwei.cyou) can't access local files, so character references are effectively not sent.

**Diagnosis steps**:
1. Check project's `characters.json` → `primaryImage` and `views[].imageUrl` values
2. If all are `local-image://` or `NONE`, the API receives no valid character refs
3. Check `sclass.json` → `shotGroups[].characterReferenceImages` and `imageRefs`

**Fix**: In `submitGridImageRequest`, before the chuangwei fetch, convert `local-image://` URLs to base64 data URLs using `materializeImageSourceToDataUrl()`.

**Patch code** (insert before `const fetchUrl = isChuangweiProxy ? ...` in the retryOperation callback):
```javascript
if (isChuangweiProxy && requestBody.image_urls && requestBody.image_urls.length > 0) {
  const converted = await Promise.all(requestBody.image_urls.map(async (url) => {
    if (url && (url.startsWith("local-image://") || url.startsWith("local-video://"))) {
      try {
        const dataUrl = await materializeImageSourceToDataUrl(url);
        return dataUrl || url;
      } catch(e) {
        console.warn("[GridImageAPI] Failed to convert local ref:", url, e.message);
        return url;
      }
    }
    return url;
  }));
  requestBody.image_urls = converted;
}
```

### 2. Image generation times out at 60 seconds

**Root cause**: Hardcoded 60s timeout in `submitViaChatCompletions` or `fetchWithTimeout$1`. The `openai_chat` format path uses a separate AbortController timeout.

**Fix**: For chuangwei.cyou, ensure the request does NOT go through the `openai_chat` path. The `isChuangweiProxy` routing already bypasses it — verify `apiFormat` is NOT `"openai_chat"`.

### 3. "Failed to fetch" errors with chuangwei.cyou

**Checklist**:
1. Verify the chuangwei routing is active: search renderer.js for `isChuangweiProxy`
2. Test connectivity: `curl -X POST https://chuangwei.cyou/api/ai/image -H "Content-Type: application/json" -d '{"prompt":"test"}'` → should return 404 (not connection error)
3. Check that `gpt-image-2-reverse` model is NOT in the memefast model list (or it would route to wrong endpoint)
4. Verify API key is being sent as `apiKey` in body, not Bearer header

### 4. Project data mismatch (wrong project ID)

When the project in `moyin-project-store.json` differs from what the user says they're working on:
- Check `runtime.db` → `studio_run_tasks` for the actual project IDs of recent tasks
- The UI may show a project that exists only in IndexedDB (runtime state), not on disk
- Use `payload_json` in runtime.db tasks to find execution parameters including `baseUrl`, `model`, `apiKey` (redacted in summary_json)

## Debugging Tactics

### Inject logging into app.asar
Add `console.log` statements before key fetch calls. The Electron console output is visible via the app's DevTools, or redirect to a file with:
```javascript
const fs = require('fs');
fs.appendFileSync('D:/debug.log', JSON.stringify({ key: currentApiKey?.substring(0,8), url, model }) + '\n');
```

### Read runtime.db
The SQLite database at `studio-run/runtime.db` contains all task history. It uses WAL mode — copy all three files (`.db`, `.db-wal`, `.db-shm`) to read a consistent snapshot:
```bash
cp runtime.db /tmp/runtime_copy.db
cp runtime.db-wal /tmp/runtime_copy.db-wal
python3 -c "import sqlite3; conn = sqlite3.connect('/tmp/runtime_copy.db'); ..."
```

## Pitfalls

- **Don't trust `summary_json` for API keys** — they're redacted to `***`. Use `payload_json` for the full execution config.
- **Project files may be empty** if the user switched projects or data is only in IndexedDB. Always cross-reference `runtime.db` task history.
- **The `_p/` directory only contains one project at a time** — other projects exist only in `runtime.db` records.
- **Modifying `app.asar` requires a full app restart** — the asar is loaded once at Electron startup.
- **The renderer.js signature** (`index-BiEM7W1o.js`) is a content hash — verify it hasn't changed before patching. If it has, the file is different and old patches may not apply.
