---
name: electron-asar-modding
description: Modify/debug Electron apps packaged as asar — extract, search minified bundles, apply targeted patches, repack, and verify. Covers the full round-trip workflow and common pitfalls.
---

# Electron asar modding

Modify a packaged Electron app by extracting its `app.asar`, editing the bundled code, and repacking — without access to the build toolchain.

## Triggers

- User wants to change behavior of an Electron app ("修改这个软件的行为", "改 asar", "魔因漫创")
- Need to fix a hardcoded value, add a feature, or debug API calls in a packaged Electron app
- User mentions `.asar`, Electron, or a known Electron app with "帮我改一下"

## Workflow

### 1. Locate the asar

```
<app_root>/resources/app.asar
```

Verify with `ls -lh` and check for `.unpacked` directory alongside it.

### 2. Extract

```bash
npx --yes @electron/asar extract /path/to/app.asar /tmp/extracted/
```

This is the **preferred command** across environments. Avoid depending on globally-installed asar — `npx` handles it.

### 3. Find the code to change

Miniified bundles live in `out/renderer/assets/index-<hash>.js`. This is a **single large file** (often 5-15 MB, 150K+ lines).

**Search strategy:**
```bash
# Broad search
grep -n 'targetString' out/renderer/assets/index-*.js

# Context around matches
sed -n '<line>,<line+30>p' out/renderer/assets/index-*.js
```

**Critical pattern:** When a value appears hardcoded, search for ALL occurrences. Minified bundles often duplicate logic across:
- Direct execution path (user clicking a button)
- Queue/task-runner path (background job processing)
- Fallback/default paths
- Different sub-features (wardrobe, scene generation, batch)

In this session, `"1:1"` appeared in **7+ execution paths** — changing only the obvious one(s) left queue-mode generation broken.

### 4. Apply replacements

**Use sed with line-address matching** rather than multi-line regex. Multi-line Perl/sed fails silently on large minified files.

Good pattern — match a context line, then change the next line:
```bash
sed -i '/uniqueContextLine/{n;s/"old"/"new"/}' file.js
```

For global single-line replacements:
```bash
sed -i 's/oldPattern/newPattern/g' file.js
```

For resolution mappings that depend on a size table, also check if the model needs to be in a **whitelist** (e.g., `needsPixelSize` array, MemeFast adapter registration).

### 5. Repack

```bash
npx --yes @electron/asar pack /tmp/extracted/ /tmp/app_new.asar
```

Then replace:
```bash
cp /tmp/app_new.asar /path/to/app/resources/app.asar
```

### 6. Verify

Before restarting, **spot-check the extracted asar** by re-extracting and grepping:
```bash
npx --yes @electron/asar extract /path/to/app/resources/app.asar /tmp/vfy/
grep -n '"16:9"' /tmp/vfy/out/renderer/assets/index-*.js | wc -l
```

### 7. Restart

For Windows apps from WSL:
```bash
taskkill.exe /F /IM "app-name.exe" 2>/dev/null
powershell.exe -Command "Start-Process 'D:\path\to\app.exe'"
```

## Pitfalls

1. **Queue mode vs direct mode.** Background task queues often run through different functions than UI-triggered generation. Always search for the value across the ENTIRE bundle, not just the obvious function.

2. **Multi-line sed/perl fails silently.** Sed `N` and Perl `-pe` process line-by-line by default. Multi-line patterns that span `\n` boundaries won't match. Use sed address ranges (`/pattern/{n;...}`) instead.

3. **Resolution table mismatch.** `"16:9"` as a string is NOT the same as the pixel dimensions the API expects. Some models need `"2048x1152"` — check whether a `needsPixelSize` whitelist or a model-specific size table applies.

4. **Re-extract to verify, don't trust.** After repacking, extract the new asar and grep — never assume the pack succeeded with your changes. Line numbers shift; grep is the only ground truth.

5. **Always backup first.** `cp app.asar app.asar.bak_$(date +%Y%m%d_%H%M%S)` before any replacement.

## References

- `references/moyin-creator-session.md` — Full session log: specific files, line numbers, chuangwei.cyou proxy routing, MemeFast adapter modifications for 魔因漫创.
