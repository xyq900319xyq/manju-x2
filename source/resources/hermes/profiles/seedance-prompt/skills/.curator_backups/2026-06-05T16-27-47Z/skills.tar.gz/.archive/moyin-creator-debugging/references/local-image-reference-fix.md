# local-image:// Reference Image Fix

## Problem

When characters have `local-image://` format reference images (common after character generation), and the API proxy is `chuangwei.cyou`, the proxy cannot access local files. The reference images are sent verbatim as `["local-image://characters/1779123367028_3ye0ev.png"]` and the proxy silently ignores them, producing images without the referenced characters.

## Root Cause Chain

1. `getCharacterPrimaryImage(char)` → returns `local-image://characters/xxx.png`
2. `buildAutoImageRef({ url })` → `httpUrl = null` (because `isRemoteLikeAssetUrl` returns false for `local-image://`)
3. Caller: `ref.httpUrl || ref.localUrl` → `"local-image://characters/xxx.png"`
4. `submitGridImageRequest({ referenceImages })` → `requestBody.image_urls = ["local-image://..."]`
5. Chuangwei proxy receives `local-image://` URL → can't resolve → character ref silently lost
6. Generated image has no character

## Fix: Convert local-image:// to base64 before sending

Insert this code in `submitGridImageRequest`, inside the `retryOperation` callback, BEFORE `const fetchUrl = ...`:

```javascript
if (isChuangweiProxy && requestBody.image_urls && requestBody.image_urls.length > 0) {
  const converted = await Promise.all(requestBody.image_urls.map(async (url) => {
    if (url && (url.startsWith("local-image://") || url.startsWith("local-video://"))) {
      try {
        const dataUrl = await materializeImageSourceToDataUrl(url);
        console.log("[GridImageAPI] Converted local ref:", url.substring(0, 40), "-> dataUrl length:", dataUrl?.length || 0);
        return dataUrl || url;
      } catch(e) {
        console.warn("[GridImageAPI] Failed to convert local ref:", url.substring(0, 40), e.message);
        return url;
      }
    }
    return url;
  }));
  requestBody.image_urls = converted;
}
```

This uses the existing `materializeImageSourceToDataUrl()` function which already handles `local-image://` → base64 conversion via `window.imageStorage.readAsBase64()`.

## Verification

After applying the patch, regenerate a nine-grid. The console should show:
```
[GridImageAPI] Converted local ref: local-image://characters/1779123... -> dataUrl length: 123456
```

Characters should now appear in the generated image.

## Alternative Root Causes (check first)

Before applying this patch, verify the character actually has reference images:

```bash
# Check project characters.json
cat workspace-data/projects/_p/<project-id>/characters.json | python3 -c "
import json,sys; d=json.load(sys.stdin);
for c in d['state']['characters']:
    print(f'{c[\"name\"]}: primaryImage={c.get(\"primaryImage\")}, views={len(c.get(\"views\",[]))}, variations={len(c.get(\"variations\",[]))}')
"
```

- If `primaryImage` is `NONE` and no views → character has no reference image at all → generate character art first
- If all character images are `local-image://` → this patch is needed
- If character images are `https://` → no patch needed, issue is elsewhere
