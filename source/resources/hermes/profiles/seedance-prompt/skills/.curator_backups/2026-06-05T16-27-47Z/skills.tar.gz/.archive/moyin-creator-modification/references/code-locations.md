# Code locations for common modifications in index-BiEM7W1o.js

## Aspect ratio for character image generation (定妆照)

### ⚠️ CRITICAL: Task Queue Path — resolveCharacterPreparedImageExecution (~line 163205)
This is the path used when `useTaskRuntimeGeneration` is true (DEFAULT behavior). Three hardcoded `"1:1"` values + `resolution: void 0` that override all other settings:

1. **Fallback object**:
   ```
   aspectRatio: "1:1",   // change to "16:9"
   resolution: void 0      // change to "2K"
   ```

2. **Explicit execution fallback**:
   ```
   aspectRatio: "1:1",   // change to "16:9"
   ```

3. **Resolved execution return**:
   ```
   aspectRatio: "1:1",   // change to "16:9"
   resolution: void 0      // change to "2K"
   ```

This feeds into `executePreparedImage` → `submitGridImageRequest({aspectRatio: execution.aspectRatio, ...})`.
**If runtime.db has tasks for `character-generation`, the user IS on this path.** Direct path changes below will NOT take effect.

### Direct Path (task queue OFF)
Three locations, all changed from `"1:1"` → `"16:9"`:

1. **Default in generateImage()** — line ~84839:
   ```
   const aspectRatio = params.aspectRatio || "16:9";
   ```

2. **generation-panel.tsx equivalent** — line ~138688:
   ```
   aspectRatio: "16:9",
   ```

3. **character-generator.tsx equivalent** — line ~142358:
   ```
   aspectRatio: "16:9",
   ```

### needsPixelSize — pixel conversion (~line 84820)
Changing the aspect ratio string alone is NOT enough. The `needsPixelSize()` function controls whether the ratio gets converted to pixel dimensions. If the model is NOT in this whitelist, `size: "16:9"` is sent as a raw ratio string — which most APIs silently ignore.

```
function needsPixelSize(model) {
  const m2 = model.toLowerCase();
  return m2.includes("doubao") || m2.includes("seedream") || m2.includes("cogview") || m2.includes("gpt-image-2") || false;
}
```

When `needsPixelSize` returns true, `ASPECT_RATIO_DIMS["16:9"]` → `size: "1280x720"`.
**However**, 1280x720 is NOT a valid GPT Image 2 API size. The API silently ignores it.
For GPT Image models, the **MemeFast adapter** is preferred — see below.

### MemeFast adapter registration (PREFERRED for GPT Image models)
The model must be in BOTH:

1. **MEMEFAST_GPT_IMAGE_2_MODELS** Set (~line 73019):
   Add `"gpt-image-2-reverse"` to the Set.

2. **MEMEFAST_GPT_IMAGE_VARIANTS** map (~line 73069):
   ```
   "gpt-image-2-reverse": {
     id: "gpt-image-2-reverse",
     outputFormatField: "output_format",
     editUploadField: "image",
     generationAspectRatios: [...GPT_IMAGE_2_COMMON_ASPECT_RATIOS],
     editAspectRatios: [...GPT_IMAGE_2_COMMON_ASPECT_RATIOS],
     generationSizes: GPT_IMAGE_2_GENERATION_SIZES,
     editSizes: OPENAI_IMAGE_SIZES
   }
   ```
   Watch for duplicate `};` closing braces when patching near the end.

The adapter uses `GPT_IMAGE_2_SIZE_BY_ASPECT_RATIO["16:9"]["2K"]` → `"2048x1152"` (valid API size).
Standard path uses `ASPECT_RATIO_DIMS["16:9"]` → `"1280x720"` (invalid, API ignores).

## Timeout locations (ALL must be changed — 4 locations total)

When increasing image generation timeouts, change ALL of these:

| # | Function | Line | Current | Change to |
|---|----------|------|---------|-----------|
| 1 | `submitViaChatCompletions` AbortController | ~85027 | `controller.abort(new DOMException("…60 seconds…")), 6e4` | `6e5` + message "600 seconds" |
| 2 | `submitViaChatCompletions` fetchWithTimeout$1 | ~85219 | `isMemefastGptImage2Model(model) ? 12e4 : 18e4` | `6e5` |
| 3 | `submitGridImageRequest` fetchWithTimeout$1 | ~85507 | `isMemefastGptImage2Model(model) ? 12e4 : 18e4` | `6e5` |
| 4 | `submitViaKlingImages` fetchWithTimeout$1 | ~85658 | `6e4` (×2 occurrences, use replace_all) | `6e5` |

**Pitfall**: Location #1 has its own DOMException message. Location #4 has TWO occurrences. Missing any location causes intermittent timeout errors from the unmodified path.

## Chuangwei.cyou proxy routing — BROKEN, must remove

The custom routing at `submitGridImageRequest` (~lines 85509-85585) sends requests to `chuangwei.cyou/api/ai/image` with `apiKey` in body. **This endpoint does NOT exist** — confirmed by direct curl test returning `"Invalid URL"`.

**Fix**: Remove ALL `isChuangweiProxy` branches. Use standard OpenAI endpoints (`/v1/images/generations`) with Bearer auth.

Keep the `local-image://` → base64 conversion but apply it **unconditionally** (not just for chuangwei):
```js
// BEFORE (broken):
const isChuangweiProxy = /chuangwei\\.cyou/i.test(normalizedBase);
// … if (isChuangweiProxy) { convert local-image → base64 } …
// … fetchUrl = isChuangweiProxy ? `${normalizedBase}/api/ai/image` : endpoint …

// AFTER (fixed):
// Remove isChuangweiProxy entirely
// Apply local-image → base64 conversion unconditionally:
if (requestBody.image_urls && requestBody.image_urls.length > 0) { … convert … }
// Always use standard endpoint:
const response = await fetchWithTimeout$1(endpoint, {
  method: "POST",
  headers: { "Authorization": `Bearer ${currentApiKey}`, … },
  body: multipartFormData || JSON.stringify(requestBody)
}, …)
```

Also remove the chuangwei response parsing (~lines 85565-85585):
```js
// REMOVE this block:
if (isChuangweiProxy) {
  if (data.imageUrl && data.status === "completed") { … }
  if (data.taskId) { … polling … }
}
```

## Verifying output dimensions
```bash
python3 -c "
import struct
with open('path/to/image.png', 'rb') as f:
    f.read(16)
    w = struct.unpack('>I', f.read(4))[0]
    h = struct.unpack('>I', f.read(4))[0]
    print(f'{w}x{h} (ratio={w/h:.3f})')
"
```

## Scene 四视图 — imageUrl fix + shared store

When generated 四视图 (orthographic front/back/left/right views) don't appear in S级 → 场景映射:

### Fix 1: Missing `imageUrl` in scenes.json

Viewpoint variant scenes may have `referenceImage` pointing to the correct file but `imageUrl` empty:
```python
for s in scenes:
    if s.get("isViewpointVariant") and not s.get("imageUrl") and s.get("referenceImage"):
        s["imageUrl"] = s["referenceImage"]
        s["imageStatus"] = "completed"
        s["imageProgress"] = 100
```

### Fix 2: Empty `_shared/scenes.json`

The scene mapping panel pulls from `projects/_shared/scenes.json`. If empty, add viewpoint variants:
```python
shared["state"]["scenes"].append({
    "id": vs["id"], "name": vs["name"], "projectId": "80120cc3-...",
    "isViewpointVariant": True, "viewpointId": vs["viewpointId"],
    "imageUrl": vs.get("imageUrl", ""), "imageStatus": "completed",
})
```

### Fix 3: Deduplicate by id

Multiple batches of 四视图 create duplicates. Deduplicate by `id` (keep latest entry).

## Source file mapping (from open-source repo)
| Bundle function | Source file |
|----------------|-------------|
| `generateCharacterImage` | `src/lib/ai/image-generator.ts:142` |
| `generateImage` | `src/lib/ai/image-generator.ts:157` |
| `submitImageTask` | `src/lib/ai/image-generator.ts` (after line 540) |
| `submitGridImageRequest` | `src/lib/ai/image-generator.ts:779` |
| `resolveCharacterPreparedImageExecution` | task executor (worker) |
| `executePreparedImage` | task executor (worker) |
| `executeCharacterImageGeneration` | task executor (worker) |
| Character gen panel | `src/components/panels/characters/generation-panel.tsx` |
| Character gen sheet | `src/components/panels/characters/character-generator.tsx` |
