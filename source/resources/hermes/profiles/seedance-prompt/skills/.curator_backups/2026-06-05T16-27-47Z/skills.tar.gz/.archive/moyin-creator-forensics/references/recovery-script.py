# Moyin Creator Recovery Script Template

This Python script matches orphaned media PNG files to their scene/group records and patches missing `imageUrl` / `gridImageUrl` fields.

## Usage
```bash
python3 recover_images.py /path/to/moyin-project
```

The script:
1. Backs up all JSON state files before modification
2. Matches `media/scenes/*.png` to scene records by timestamp
3. Sets `imageUrl`, `imageStatus: "completed"` on matched scenes
4. Finds the largest PNG near scene-contact-sheet time and sets it as S-class `gridImageUrl`
5. Adds a recovery entry to `groupBoardHistory`

```python
#!/usr/bin/env python3
"""Recover orphaned Moyin Creator images"""
import json, os, glob, shutil, sys
from datetime import datetime

PROJECT_DIR = sys.argv[1] if len(sys.argv) > 1 else '.'
SCENES_FILE = os.path.join(PROJECT_DIR, 'projects/_p/*/scenes.json')
SCLASS_FILE = os.path.join(PROJECT_DIR, 'projects/_p/*/sclass.json')
MEDIA_DIR = os.path.join(PROJECT_DIR, 'media/scenes')

def backup(path):
    backup = path + '.backup_' + datetime.now().strftime('%Y%m%d_%H%M%S')
    shutil.copy2(path, backup)
    print(f'Backed up: {backup}')

def match_pngs_to_scenes(scenes):
    pngs = glob.glob(os.path.join(MEDIA_DIR, '*.png'))
    png_map = {}
    for p in pngs:
        ts_str = os.path.basename(p).split('_')[0]
        if ts_str.isdigit():
            png_map[int(ts_str)] = os.path.basename(p)
    
    fixes = []
    for s in scenes:
        sid = s.get('id', '')
        scene_ts = int(sid.split('_')[0]) if '_' in sid else s.get('createdAt', 0)
        if not scene_ts:
            continue
        
        best = min(
            ((abs(ts - scene_ts), fname) for ts, fname in png_map.items() if abs(ts - scene_ts) < 500),
            key=lambda x: x[0],
            default=None
        )
        if best:
            fixes.append((s, best[1]))
    return fixes

def fix_scenes(scenes_file):
    backup(scenes_file)
    with open(scenes_file) as f:
        data = json.load(f)
    
    scenes = data['state']['scenes']
    fixes = match_pngs_to_scenes(scenes)
    
    for scene, fname in fixes:
        scene['imageUrl'] = f'local-image://scenes/{fname}'
        scene['imageDataUrl'] = ''
        scene['imageStatus'] = 'completed'
        scene['imageProgress'] = 100
        scene['imageError'] = None
    
    with open(scenes_file, 'w') as f:
        json.dump(data, f, ensure_ascii=False, separators=(',', ':'))
    print(f'Fixed {len(fixes)} scenes')

if __name__ == '__main__':
    for f in glob.glob(SCENES_FILE):
        fix_scenes(f)
