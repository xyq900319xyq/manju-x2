---
name: electron-asar-modification
description: Modify closed-source Electron apps by extracting, patching, and repacking their asar archives. Also covers debugging renderer code when DevTools is disabled.
---

## Triggers
- User needs to fix a bug, change behavior, or add features to a closed-source Electron app
- User mentions `app.asar`, `asar extract`, or modifying an Electron app's internals
- User says "DevTools is disabled" or "can't open F12" in an Electron app

## Workflow

### 1. Extract the asar

```bash
npx @electron/asar extract "/path/to/app.asar" /tmp/extracted/
```

### 2. Find the main bundle

The renderer code is usually in a single large minified JS file:

```bash
find /tmp/extracted -name "*.js" -size +1M | head -5
# Typically: out/renderer/assets/index-XXXXXX.js
```

Search for target strings to locate relevant code:

```bash
grep -n "targetFunction\|targetString" /tmp/extracted/out/renderer/assets/index-*.js
```

### 3. Make targeted patches

Use the `patch` tool (mode='replace') with unique surrounding context for each change. Keep a backup:

```bash
cp app.asar app.asar.bak
```

### 4. Repack and replace

```bash
npx @electron/asar pack /tmp/extracted/ /tmp/app_new.asar
cp /tmp/app_new.asar "/path/to/app.asar"
```

### 5. Restart the app

Kill all processes and restart:

```bash
taskkill.exe /F /IM "app.exe"
powershell.exe -Command "Start-Process 'D:\path\to\app.exe'"
```

## Debugging without DevTools

When DevTools is disabled (common in production Electron apps):

### HTTP ping injection
The most reliable technique — inject a ping into the button's onClick handler to confirm it fires:

```js
onClick: () => { window.electronAPI?.httpRequest({url:"http://127.0.0.1:9999/ping",method:"GET"}).catch(()=>{}); originalHandler(); },
```

Start a listener:
```bash
python3 -u -c "
import http.server
class H(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        with open('/tmp/ping.log', 'a') as f:
            f.write(f'PING {self.path}\n')
        self.send_response(200); self.end_headers(); self.wfile.write(b'ok')
http.server.HTTPServer(('0.0.0.0', 9999), H).serve_forever()
" &
```

### State monitoring
Electron apps often persist state as JSON files. Monitor them for changes to track generation progress:

```python
import json, time
while True:
    with open("state.json") as f:
        data = json.load(f)
    # Check status fields...
    time.sleep(3)
```

## Common Pitfalls

### Pitfall 1: Minified file hash changes
The JS filename includes a content hash (`index-XXXXXX.js`). When repacking, the hash stays the same since we modify in-place, but ensure `patch` is applied to the correct extracted file.

### Pitfall 2: Variable scope after patching
When removing code blocks, check that referenced variables are still defined. If you remove a variable declaration that's used later, the app will crash silently.

### Pitfall 3: Retry loops hide fast errors
If a `retryOperation` wraps the fetch but the endpoint is invalid, 3 retries × 3s delay = 9s wasted before the real error surfaces. Test endpoints directly with `curl` first.

### Pitfall 4: Status fields are stale after app restart
If the app stores state in JSON files and you modify them while the app is closed, the app may still have in-memory state when it restarts. Force-clear all generating/failed states before restarting.

### Pitfall 5: Timeout errors may come from unexpected code paths
Search for ALL timeout constants (`6e4`, `12e4`, `18e4`, "timed out after") — there are often multiple paths (chat, standard, Kling) each with their own timeout.

## Reference Files
- `references/moyin-creator-fixes.md` — Specific fixes applied to 魔因漫创 (chuangwei routing, timeouts, aspect ratio, character references)
