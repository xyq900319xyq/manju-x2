# Scene 四视图 & 场景映射 Fix

## Problem
Generated 四视图 (4-view: front/back/left/right) doesn't appear in 场景映射 (scene mapping) panel.

## Root Causes

### 1. Missing `imageUrl` on viewpoint variants
In `scenes.json`, viewpoint variant entries may have `referenceImage` but NOT `imageUrl`. The UI needs `imageUrl` to display images.

Fix:
```python
for s in scenes:
    if s.get("isViewpointVariant") and not s.get("imageUrl") and s.get("referenceImage"):
        s["imageUrl"] = s["referenceImage"]
        s["imageDataUrl"] = ""
        s["imageStatus"] = "completed"
        s["imageProgress"] = 100
        s["imageError"] = None
```

### 2. Empty shared scene store
`projects/_shared/scenes.json` must contain entries for the scene mapping dropdown. If `"scenes": []`, nothing appears.

Fix: Add viewpoint variant entries to the shared store with `id`, `name`, `parentSceneId`, `projectId`, `imageUrl`, `referenceImage`, etc.

## Data Flow
- Scene library: `projects/_p/<id>/scenes.json` — all scenes including viewpoint variants
- Shared store: `projects/_shared/scenes.json` — curated list shown in scene mapping UI
- Media files: `media/scenes/<timestamp>_<hash>.png` — `local-image://scenes/<filename>` resolves here
- Storyboard bindings: `sclass.json` → `splitScenes[].sceneLibraryId` + `sceneReferenceImage`
