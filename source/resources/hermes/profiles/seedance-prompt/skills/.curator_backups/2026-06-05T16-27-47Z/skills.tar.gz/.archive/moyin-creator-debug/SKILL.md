---
name: moyin-creator-debug
description: Debug 魔因漫创（moyin-creator）Electron 应用的图片/视频生成问题。覆盖 asar 代码逆向、状态文件分析、API 请求追踪、角色参考图链路诊断。
---

# 魔因漫创调试

## 触发条件
用户报告魔因漫创中图片不显示、生成失败、角色丢失、九宫格异常等问题。

## 数据位置

```
项目数据（自定义路径）:
  D:\moyinxiangmu\  (WSL: /mnt/d/moyinxiangmu/)
    projects/_p/{project-uuid}/
      sclass.json       ← S级分组状态（gridGenerationStatus, gridImageUrl）
      scenes.json       ← 场景数据（imageUrl, contactSheetUrl, characterIds）
      characters.json   ← 项目级角色（name, views, variations, primaryImage）
      director.json     ← 导演模式分镜数据（splitScenes, characterIds）
      script.json       ← 剧本数据
      media.json        ← 媒资映射
    media/
      characters/       ← 角色图片文件（PNG）
      scenes/           ← 场景图片文件（PNG）
    projects/
      moyin-character-library.json  ← 全局角色库
      moyin-project-store.json      ← 项目列表

Windows AppData:
  %APPDATA%/Roaming/魔因漫创-profiles/default-{hash}/
  关键路径（WSL 下）：
  /mnt/c/Users/Administrator/AppData/Roaming/魔因漫创-profiles/default-58d22b804dd3/

  studio-run/
    runtime.db            ← SQLite：任务历史、API 调用记录
      studio_run_tasks   ← 任务表（category, label, status, summary_json）
      studio_run_jobs    ← 作业表

app.asar:
  D:\魔因\moyin-creator\resources\app.asar  (WSL: /mnt/d/魔因/moyin-creator/resources/app.asar)
  关键文件：
    out/main/index.cjs           ← 主进程
    out/renderer/assets/index-BiEM7W1o.js  ← 渲染进程（~7.4MB，所有 UI 和 API 逻辑）
    out/renderer/assets/ai-worker-CNEoMg1t.js  ← worker 线程
```

## 诊断步骤

### 1. 读取状态文件确认问题
```python
import json

# 检查 S级九宫格状态
with open("sclass.json") as f:
    data = json.load(f)
groups = data["state"]["projectData"]["shotGroups"]
for g in groups:
    print(f"{g['name']}: status={g.get('gridGenerationStatus')}, error={g.get('gridGenerationError')}")

# 检查场景图片关联
with open("scenes.json") as f:
    scenes = json.load(f)["state"]["scenes"]
for s in scenes:
    print(f"{s['name']}: imageUrl={s.get('imageUrl')}, characterIds={s.get('characterIds')}")

# 检查角色定妆照
with open("characters.json") as f:
    chars = json.load(f)["state"]["characters"]
for c in chars:
    print(f"{c['name']}: primaryImage={c.get('primaryImage')}, views={len(c.get('views',[]))}, variations={len(c.get('variations',[]))}")
```

### 2. 提取 asar 追踪代码
```bash
cd /tmp && npm install asar
node -e "
const asar = require('./node_modules/asar');
const content = asar.extractFile('app.asar', 'out/renderer/assets/index-BiEM7W1o.js').toString();
require('fs').writeFileSync('/tmp/renderer.js', content);
"
```

### 3. 追踪角色参考图链路
关键函数（在 renderer.js 中）：
- `getCharacterPrimaryImage(char)` — 获取角色主图（优先 primaryRevision.imageUrl → front view → thumbnailUrl）
- `collectCharacterRefs(characterIds, characters)` — 收集角色参考图
- `buildAutoImageRef({url})` — 构建图片引用（httpUrl 仅对 https:// 和 asset:// 非空）
- `collectAllRefs(group, scenes, ...)` — 汇总所有参考
- `submitGridImageRequest({referenceImages, ...})` — 发送 API 请求

**关键问题**：`isRemoteLikeAssetUrl(url)` 只认 `http(s)://` 和 `asset://`。`local-image://` 格式的 URL 导致 `httpUrl = null`，回退到 `localUrl`，远程 API 无法访问。

### 4. 修改 asar
```bash
# 备份
cp app.asar app.asar.bak_$(date +%Y%m%d_%H%M%S)

# 提取、修改、重打包
node -e "
const asar = require('/tmp/node_modules/asar');
const fs = require('fs');
const path = require('path');
const tmpDir = '/tmp/asar_work';
fs.rmSync(tmpDir, {recursive: true, force: true});
asar.extractAll('app.asar', tmpDir);
// 修改文件...
fs.copyFileSync('/tmp/patched.js', path.join(tmpDir, 'out/renderer/assets/index-BiEM7W1o.js'));
asar.createPackage(tmpDir, 'app.asar.new');
"
cp app.asar.new app.asar

# 关闭并重启应用
ps aux | grep moyin-creator | grep -v grep | awk '{print $2}' | xargs -r kill
```

详细角色参考链路分析见 `references/character-ref-flow.md`。
chuangwei.cyou 代理的 local-image:// 转换修复见 `references/chuangwei-local-image-fix.md`。

## 常见问题

### 九宫格生成成功但画面缺角色
**根因**：角色参考图是 `local-image://` 格式，chuangwei.cyou 代理无法访问本地文件。
**验证**：
1. 检查 `characters.json` 中 `primaryImage` 和 `variations` 是否有图
2. 检查图片 URL 格式：`isRemoteLikeAssetUrl()` 只认 `http(s)://` 和 `asset://`，`local-image://` 的 `httpUrl` 为 null
3. 若 `collectCharacterRefs` 中 `imageUrl` 为空，角色直接被跳过
**修复方案A（推荐）**：在角色板块重新生成定妆照，获得远程 URL
**修复方案B（代码级）**：在 `submitGridImageRequest` 的 chuangwei 路径中，调用前将 `local-image://` URL 转为 base64 data URL。代码中已有 `materializeImageSourceToDataUrl(url)` 可复用。详见 `references/chuangwei-local-image-fix.md`。

### 图片 API 返回但软件不显示
**根因**：任务完成后 imageUrl 未写回 JSON 状态文件。
**验证**：检查 `scenes.json` 中 `imageUrl` 字段。
**修复**：手动匹配 media 目录下的 PNG 文件并补全 imageUrl。

### 九宫格生成超时
**根因**：chuangwei.cyou 代理延迟高，默认 60s 超时不够。
**验证**：搜索 `submitTimeoutMs` 在 renderer.js 中的值。
**修复**：改为 `18e4`（180秒），并确保 chuangwei.cyou 检测逻辑存在。

### 角色定妆照比例修改不生效
**根因**：只改了 `aspectRatio: "1:1"` → `"16:9"` 但模型不在 `needsPixelSize()` 白名单。API 收到 `size: "16:9"`（比例字符串）而非 `size: "1280x720"`（像素字符串），API 不认识比例字符串，静默退回默认尺寸。
**验证**：检查生成图片实际尺寸 — `python3 -c "import struct; f=open('img.png','rb'); f.read(16); print(struct.unpack('>II', f.read(8)))"` — 若比例不对（如 0.84-0.91 而非 0.5625=16:9），说明参数未生效。
**修复**（两处都要改）：
1. 改 `aspectRatio` 值（三处：generateImage 默认 + generation-panel + character-generator）
2. 改 `needsPixelSize()` 函数（line ~84820），加入 `m2.includes("gpt-image-2")` 让模型名含 `gpt-image-2` 的都走像素尺寸转换

### asar 修改后不生效
- 必须完全关闭应用再启动（Electron 启动时加载 asar）
- 修改前备份原文件
- **关闭应用必须用 `taskkill.exe /f /im "moyin-creator.exe"` 杀 Windows 进程**（WSL 的 `ps aux | grep` 看不到 Windows 侧的 Electron 子进程）
- 关闭后验证：`ps aux | grep moyin | grep -v grep` 应为空 + `taskkill.exe` 确认无残留
- **DrvFs 下 `cp` 大文件（150MB+ asar）可能静默截断**，替换后必须验证文件大小一致：`ls -la app.asar app.asar.new`
- 若被截断，从备份恢复后重试
