# S级 九宫格 Generation Flow

## Button Location
The "生成九宫格参考图" button is rendered inside `NineGridSectionShell` for the primary group:

```js
// Line ~115224 in index-<hash>.js
<Button
  variant="default"
  disabled: isGeneratingAny || isGridBusy || isOverBudget || !onGenerateGroupGrid,
  onClick: () => onGenerateGroupGrid?.(group.id),
  children: isGridGenerating ? "生成中" : hasGroupGrid2 ? "生成更多九宫格参考图" : "生成九宫格参考图"
/>
```

**Note**: The non-primary groups have a different button at ~line 114425 with an additional disabled condition:
```js
disabled: isGridBusy || !canGenerateGroupVideo || isAwaitingDirectorApproval || isNineGrid && !hasGroupGrid2 && !onGenerateGroupGrid
```

## Disabled State Checklist
If button is greyed out, check:
1. `isGeneratingAny` — another group is generating → wait for it
2. `isGridBusy` — group's `gridGenerationStatus === "generating"` or upload in progress
3. `isOverBudget` — video duration exceeds max → reduce scenes
4. `!onGenerateGroupGrid` — callback undefined → React component wiring issue

## Generation Handler: `handleGenerateGroupGridReference`
Located at ~line 133518. Flow:
1. Find group by ID from `shotGroups`
2. Verify group is `nine-grid` style
3. Get image generation config (`getImageGenerationConfig()`)
4. Collect character references from scenes' `characterIds` (NOT from `storyboardConfig.characterReferenceImages`)
5. Build board prompt with layout, style, numbering
6. Call `updateShotGroup(groupId, { gridGenerationStatus: "generating", gridGenerationError: null })`
7. Submit API request → `submitGridImageRequest` or similar

## Key: gridGenerationStatus lives in shotGroups, NOT gridGroups
```json
// sclass.json
"shotGroups": [{
  "gridGenerationStatus": "idle|generating|failed|completed",
  "gridGenerationError": "...",
  "groupGridAsset": { "localUrl": "...", "httpUrl": "..." }
}]
```

To check status: read `sclass.json` → `state.projectData.shotGroups[i].gridGenerationStatus`

## canGenerateGroupVideo gate
```js
const canGenerateGroupVideo = !isGeneratingAny && !hasDurationBudgetIssue && !isDirectorBlocked && (!isNineGrid || hasGroupGrid2);
```
This means `canGenerateGroupVideo` is FALSE when `isNineGrid && !hasGroupGrid2` — the normal initial state. The non-primary group button is disabled in this state, but the primary group button has its own simpler condition.

The `handlePrimaryGenerate` at ~line 113617 has:
```js
if (!canGenerateGroupVideo || isAwaitingDirectorApproval) return;  // ← returns before nine-grid check!
if (isNineGrid && !hasGroupGrid2) {
    onGenerateGroupGrid?.(group.id);  // unreachable due to above gate
    return;
}
```
This is a potential bug in non-primary groups where the `!canGenerateGroupVideo` gate blocks the nine-grid path.
