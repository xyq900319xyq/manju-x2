# Aspect Ratio: 1:1 → 16:9 — All Locations

There are **7 hard-coded locations** in `out/renderer/assets/index-<hash>.js`:

| # | Function | Context Pattern | Lines (approx) |
|---|----------|----------------|----------------|
| 1 | `prepareCharacterDraftExecution` | `prompt: params.prompt,\n        aspectRatio: "1:1"` → `"16:9"` | ~138030 |
| 2 | `resolveCharacterPreparedImageExecution` fallback | `prompt: input.prompt,\n    aspectRatio: "1:1"` → `"16:9"` + `resolution: void 0` → `"2K"` | ~163208 |
| 3 | Same, explicitExecution | `prompt: input.prompt,\n      aspectRatio: "1:1"` → `"16:9"` | ~163219 |
| 4 | Same, runtime task | `prompt: input.prompt,\n    aspectRatio: "1:1"` → `"16:9"` + `resolution: void 0` → `"2K"` | ~163245 |
| 5 | Wardrobe outfitPromptConfig | `outfitPromptConfig?.aspectRatio \|\| "1:1"` → `"16:9"` | ~142139 |
| 6 | Wardrobe outfitPromptConfig | (same pattern, 2nd occurrence) | ~142152 |
| 7 | Wardrobe variation execution | `input.execution.aspectRatio \|\| "1:1"` → `"16:9"` | ~165284 |

## Safe sed approach

Multi-line sed fails. Use single-line patterns:

```bash
FILE="/tmp/extract_work/extracted/out/renderer/assets/index-*.js"

# Global single-line patterns
sed -i 's/outfitPromptConfig?\.aspectRatio || "1:1"/outfitPromptConfig?.aspectRatio || "16:9"/g' $FILE
sed -i 's/input\.execution\.aspectRatio || "1:1"/input.execution.aspectRatio || "16:9"/g' $FILE
sed -i 's/resolution: void 0/resolution: "2K"/g' $FILE

# Context + next-line: matches ALL prompt: lines and changes the following "1:1"
sed -i '/prompt: params\.prompt,/{n;s/"1:1"/"16:9"/}' $FILE
sed -i '/prompt: input\.prompt,/{n;s/"1:1"/"16:9"/}' $FILE
```

## Also needed: Model size mapping

`gpt-image-2-reverse` needs to be in the MemeFast adapter's size map so `"16:9"` → `"2048x1152"`. Without this, `needsPixelSize` produces `"1280x720"` which the API ignores.
