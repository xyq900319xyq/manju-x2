# chuangwei.cyou API Routing Fix

## Problem
The standard OpenAI-compatible image generation path (`/v1/images/generations` with Bearer auth) is incompatible with chuangwei.cyou proxy (`/api/ai/image` with apiKey in body).

## Required Modifications in `submitGridImageRequest`

### 1. Timeout increase
- Default `submitTimeoutMs`: `6e4` (60s) → `18e4` (180s) — 2 locations
- `AbortController` timeout in `submitViaChatCompletions`: `6e4` → `18e4` — 1 location

### 2. chuangwei.cyou detection
Add regex check for `chuangwei.cyou` in the base URL before the standard OpenAI path.

### 3. Endpoint change
When detected, route to `/api/ai/image` instead of `/v1/images/generations`.

### 4. Auth change
Put `apiKey` in request body (not Bearer header):
```json
{
  "apiKey": "<key>",
  "model": "gpt-image-2-reverse",
  "prompt": "...",
  "size": "2048x1152",
  "n": 1
}
```

### 5. Response parsing
chuangwei.cyou returns: `{ "data": { "imageUrl": "...", "taskId": "..." } }`
Standard OpenAI returns: `{ "data": [{ "url": "..." }] }`
Adapt the response parser for both formats.

### 6. Polling endpoint
Use `/api/ai/task/{taskId}` instead of standard OpenAI polling.

### 7. Skip chat completions path
Add early return to prevent chuangwei.cyou requests from falling through to `submitViaChatCompletions`.

## Model Size Mapping
`gpt-image-2-reverse` needs proper size mapping. Without it:
- `needsPixelSize` produces `"1280x720"` → API ignores → default size
- With MemeFast adapter: `"16:9"` → `"2048x1152"` → correct output
