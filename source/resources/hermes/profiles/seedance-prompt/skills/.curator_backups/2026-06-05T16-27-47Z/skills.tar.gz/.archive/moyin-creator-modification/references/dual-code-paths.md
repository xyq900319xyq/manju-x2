# Dual Code Paths for Image Generation

The app has TWO completely separate code paths for image generation. When modifying aspect ratio (or any generation parameter), you MUST modify both paths. Modifying only one means changes silently fail if the user uses the other path.

## Path 1: Direct (task queue OFF)

```
generation-panel.tsx / character-generator.tsx
  → generateCharacterImage({aspectRatio: "1:1", referenceImages, ...}, imageModelConfig)
    → generateImage(params, "character_generation", configOverride)
      → submitImageTask(prompt, aspectRatio, resolution, apiKey, referenceImages, model, baseUrl, ...)
        → POST /v1/images/generations with Bearer auth
```

**When this path is used**: When `useTaskRuntimeGeneration` is `false` (task queue feature is OFF in the app).

**Where to modify** (for aspect ratio changes):
- Call sites in `generation-panel.tsx` (~line 418) and `character-generator.tsx` (~line 127): `aspectRatio: "1:1"`
- Default in `generateImage` (~line 172): `params.aspectRatio || "1:1"`
- `needsPixelSize()`: add model name so ratio → pixel conversion happens
- `MEMEFAST_GPT_IMAGE_2_MODELS` + `MEMEFAST_GPT_IMAGE_VARIANTS`: register model for proper size mapping

## Path 2: Task Queue (task queue ON — this is the DEFAULT)

```
studio-run job with kind: "character-image-generation"
  → executeCharacterImageGeneration(taskId, input, signal)
    → resolveCharacterPreparedImageExecution(taskId, input)  ← ⚠️ HARDCODED "1:1" HERE
      → executePreparedImage(execution, signal, onProgress)
        → submitGridImageRequest({
            model, prompt, apiKey, baseUrl,
            aspectRatio: execution.aspectRatio,  ← from resolveCharacter... above
            resolution: execution.resolution,
            referenceImages, keyManager, signal
          })
        → chuangwei.cyou routing: POST /api/ai/image with apiKey in body
          OR standard: POST /v1/images/generations with Bearer auth
```

**When this path is used**: When `useTaskRuntimeGeneration` is `true` (task queue feature is ON — this is the default in recent versions). Evidence: runtime.db has `studio_run_tasks` with `category='character-generation'`.

**Where to modify** (for aspect ratio changes):
- `resolveCharacterPreparedImageExecution` — **3 hardcoded** `"1:1"` values:
  1. `fallback` object (line ~163208)
  2. `explicitExecution` fallback (line ~163219)
  3. Resolved execution return (line ~163244)
- Also change `resolution: void 0` → `"2K"` in all 3 places

**This is the CRITICAL path that's usually missed.** If runtime.db shows tasks for character-generation, the user IS on this path.

## How to determine which path is active

Check runtime.db:
```sql
SELECT id, category, label, status FROM studio_run_tasks 
WHERE category='character-generation' ORDER BY id DESC LIMIT 5;
```

If tasks exist → task queue path (Path 2).
If no tasks but images were generated → direct path (Path 1).

Also check: the generation-panel code has `if (useTaskRuntimeGeneration) { ... return; }` — when this branch is taken, the direct `generateCharacterImage` call below it is NEVER reached.
