# Moyin Creator Runtime Database Schema

## Tables

### studio_run_tasks
| Column | Type | Description |
|--------|------|-------------|
| id | TEXT | Task ID, format: `studio-run-{timestamp}-{random}` |
| category | TEXT | Task category (scene-generation, character-generation, script-import, etc.) |
| label | TEXT | Human-readable label |
| project_id | TEXT | Project UUID |
| module_source | TEXT | Module origin (scenes, characters, script) |
| lane | TEXT | Execution lane (image, workflow) |
| provider | TEXT | API provider identifier |
| model | TEXT | Model name (gpt-image-2-reverse, gpt-5.4, gemini-3.1-pro-preview) |
| artifact_type | TEXT | Output artifact type (scene, character) |
| artifact_id | TEXT | Target artifact ID |
| artifact_label | TEXT | Human-readable artifact label |
| route_tab | TEXT | UI route tab |
| route_label | TEXT | UI route label |
| payload_json | TEXT | JSON payload for the job |
| status | TEXT | pending, running, completed, failed |
| error_text | TEXT | Error message if failed |
| summary_json | TEXT | Result summary (imageUrl, childSceneCount, etc.) |
| progress | INTEGER | Progress percentage |
| created_at | INTEGER | Unix timestamp (ms) |
| completed_at | INTEGER | Unix timestamp (ms) |

### studio_run_jobs
| Column | Type | Description |
|--------|------|-------------|
| task_id | TEXT | FK to studio_run_tasks.id |
| queue_name | TEXT | Queue (workflow) |
| job_kind | TEXT | Job type |
| job_payload_json | TEXT | Full job input (prompt, execution config, characterSeed, etc.) |
| job_state | TEXT | completed, running, failed |
| created_at | INTEGER | Unix timestamp (ms) |

## Common Job Kinds
- `character-image-generation` — Character sheet generation
- `scene-image-generation` — Scene concept image
- `scene-contact-sheet` — 3x3 viewport contact sheet (scene level)
- `scene-orthographic-image` — 4-view (2x2) orthographic
- `script-import-full-workflow` — Script import + analysis
- `script-generate-synopses` — Episode synopsis generation
- `script-scene-calibration` — Scene calibration
- `script-character-calibration` — Character calibration
- `script-calibrate-episode-shots` — Shot calibration
- `script-regenerate-all-shots` — Full shot regeneration

## Key Diagnostic Queries

```sql
-- All tasks with their jobs
SELECT t.id, t.category, t.label, t.status, t.error_text, 
       j.job_kind, j.job_state
FROM studio_run_tasks t
JOIN studio_run_jobs j ON j.task_id = t.id
ORDER BY t.created_at DESC;

-- Character generation prompts
SELECT j.job_payload_json 
FROM studio_run_jobs j 
WHERE j.job_kind = 'character-image-generation'
ORDER BY j.created_at DESC;

-- Scene contact sheet results
SELECT t.summary_json
FROM studio_run_tasks t
JOIN studio_run_jobs j ON j.task_id = t.id
WHERE j.job_kind = 'scene-contact-sheet';
```

## S-class State (sclass.json)

Key fields per ShotGroup:
- `gridGenerationStatus` — "idle", "generating", "completed", "failed"
- `gridGenerationError` — Error message if failed
- `gridImageUrl` — local-image:// URL to the generated grid
- `groupGridAsset` — Full asset reference object
- `groupGridMediaId` — Media library ID
- `groupBoardHistory` — Array of board generation records
- `mergedPrompt` — User-editable merged prompt
- `lastPrompt` — Last generated prompt
- `videoStatus` — Video generation status
- `videoUrl` — Generated video URL

## Scene State (scenes.json)

Key fields per Scene:
- `imageUrl` — local-image:// URL (may be missing after failed save)
- `imageDataUrl` — Base64 data URL (may be empty)
- `imageHttpUrl` — HTTP URL from API
- `imageStatus` — "idle", "generating", "completed", "failed"
- `orthographicImage` — 4-view orthographic image URL
- `referenceImage` — Reference image binding
- `createdAt` — Unix timestamp (ms)
