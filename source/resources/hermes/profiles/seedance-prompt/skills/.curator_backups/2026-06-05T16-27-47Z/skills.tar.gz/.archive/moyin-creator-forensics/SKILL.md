---
name: moyin-creator-forensics
description: Diagnose Moyin Creator (魔因漫创) issues — why images/videos don't appear, where generated files go, how to fix broken state. Covers data forensics across runtime.db, JSON state files, and media directories.
---

# Moyin Creator Forensics

## When to load this skill
- User reports generated images/videos not appearing in the software
- "API shows the image but software doesn't display it"
- "Generated something but can't find it"
- Any Moyin Creator data/recovery investigation

## Key Data Locations

| What | Where |
|------|-------|
| App install | `D:\魔因\moyin-creator` (or user-chosen) |
| Project data | `D:\\moyinxiangmu\\` (primary); also `D:\\魔因项目\\` (legacy) |
| Electron userData | `%APPDATA%\Roaming\魔因漫创-profiles\default-*\` |
| Runtime task DB | `studio-run/runtime.db` (SQLite) |
| S-class state | `projects/_p/{projectId}/sclass.json` |
| Director state | `projects/_p/{projectId}/director.json` |
| Scene state | `projects/_p/{projectId}/scenes.json` |
| Character state | `projects/_p/{projectId}/characters.json` |
| Media files | `media/scenes/`, `media/shots/`, `media/characters/` |
| App source (asar) | `resources/app.asar` — extract with `npx @electron/asar extract` |

## Diagnostic Flow: "Image generated but not showing"

### Step 1: Check the runtime task database
```sql
SELECT t.id, t.category, t.label, t.status, t.error_text, t.summary_json
FROM studio_run_tasks t
JOIN studio_run_jobs j ON j.task_id = t.id
ORDER BY t.created_at DESC
```

### Step 2: If no matching task → check S-class state directly
The S-class 9-grid board generation does NOT use the studio-run task system. It uses direct API calls.

```python
# Check sclass.json for gridGenerationStatus
with open('projects/_p/{projectId}/sclass.json') as f:
    data = json.load(f)
for g in data['state']['projectData']['shotGroups']:
    print(g['gridGenerationStatus'], g['gridGenerationError'])
```

### Step 3: Match media files to scene records
Media files are named `{timestamp}_{random}.png`. Match the timestamp prefix to scene `createdAt` timestamps (~500ms tolerance).

### Step 4: Fix missing imageUrl associations
When the API generates successfully but the software fails to save the URL:
1. Find the generated PNG in `media/` directories
2. Construct `local-image://scenes/{filename}` or `local-image://shots/{filename}`
3. Set `imageUrl` on the scene, or `gridImageUrl` on the shotGroup
4. Set `imageStatus: "completed"`, clear `imageError`

## Common Failure Modes

### 1. Grid submission timeout (S-class 9-grid)
**Symptom**: `gridGenerationStatus: "failed"`, error: "拼图生成请求超时（60秒）"
**Root cause chain** (check in order):
1. **Timeout value**: `submitGridImageRequest` defaults to 60s for non-memefast models. Fix: bump `6e4` → `18e4` in all `submitTimeoutMs` lines.
2. **Endpoint mismatch** (much more common): S-class board generation uses `submitGridImageRequest` which calls standard OpenAI paths (`/v1/images/generations`), but the chuangwei.cyou proxy only serves `/api/ai/image`. The fetch fails with "Failed to fetch" instead of timing out. Fix: detect `chuangwei.cyou` in baseUrl and override endpoint to `/api/ai/image`, auth to `apiKey` in body (not `Bearer` header), and response parsing to camelCase fields (`data.imageUrl`).
3. **Model whitelist trap**: Adding a model to `MEMEFAST_GPT_IMAGE_2_MODELS` to get the 120s timeout ALSO changes the API endpoint path to memefast-specific routes. The model must NOT be in the whitelist if chuangwei.cyou is the proxy. Only bump the fallback timeout.

**Recovery**: 
- If API completed (chuangwei.cyou shows image): download manually from API history, upload to software
- If API didn't complete (network error): apply the asar patches above, reset `gridGenerationStatus` from `"failed"` to `"idle"`, restart app, retry
- Check `media/shots/` for any partially downloaded files (unlikely — timeout happens at submit stage, before data transfer)

### 2. Task completed but imageUrl missing
**Symptom**: `studio_run_tasks.status = "completed"` but scene has no `imageUrl`
**Cause**: Task handler created child scenes but failed to save the result URL.
**Fix**: Match media PNGs to scenes by timestamp proximity, patch `imageUrl`.

### 3. Task stuck "running" forever
**Symptom**: Task status stays `running` but API already completed
**Cause**: Polling failed or result handler crashed silently
**Fix**: 
- Check if the image file exists in `media/`
- If yes, manually set `imageUrl` and `imageStatus: "completed"`
- The task status itself is cosmetic — the state file is what matters

### 5. Aspect ratio change doesn't take effect
**Symptom**: Changed `aspectRatio: "1:1"` → `"16:9"` in code, but generated images still come out at wrong ratio (e.g., 0.84-0.91 instead of 0.5625=16:9)
**Root cause**: The model wasn't in `needsPixelSize()` whitelist. The API receives a ratio string (`size: "16:9"`) instead of pixel dimensions (`size: "1280x720"`), and silently falls back to default dimensions.
**Diagnosis**: Check actual output with `python3 -c "import struct; f=open(img,'rb'); f.read(16); w,h=struct.unpack('>II',f.read(8)); print(w/h)"`
**Fix**: Add the model to `needsPixelSize()` function — e.g., `m2.includes("gpt-image-2")` to cover gpt-image-2-reverse. See `moyin-creator-modification` skill's `references/code-locations.md` for exact positions.

### 6. "Failed to fetch" on grid generation (chuangwei.cyou routing)
**Symptom**: `gridGenerationStatus: "failed"`, error: "Failed to fetch" (NOT a timeout message)
**Root cause**: S-class board generation (`submitGridImageRequest`) calls OpenAI-standard paths (`/v1/images/generations`) with `Bearer` auth. The chuangwei.cyou proxy only serves `/api/ai/image` with `apiKey` in the request body. The endpoint doesn't exist → immediate fetch failure, not a timeout.
**Diagnosis**: Check the error message. "拼图生成请求超时（60秒）" = timeout at submit. "Failed to fetch" = wrong endpoint.
**Fix** (in compiled JS `submitGridImageRequest`):
1. Detect `chuangwei.cyou` in baseUrl: `const isChuangwei = /chuangwei\.cyou/i.test(normalizedBase);`
2. Override endpoint: `const fetchUrl = isChuangwei ? ${normalizedBase}/api/ai/image : endpoint;`
3. Override auth: Put `apiKey` in body (not `Authorization` header)
4. Override response parsing: `data.imageUrl` (camelCase) instead of `data.url`/`data.image_url`
5. Handle async task polling: `GET /api/ai/task/{taskId}?provider=memefast&type=image&apiKey=...`
**See**: `electron-app-analysis` skill, Phase 5 for the full asar patching recipe.

## Diagnostic Priority

When the user says "API shows image but software doesn't":
1. **Check `gridGenerationStatus` FIRST** — read `sclass.json`, not `runtime.db`. S-class board generation doesn't use the task runtime.
2. **Read the error message** — "超时" = timeout, "Failed to fetch" = endpoint mismatch
3. **Only match files if status is `completed`** — if it's `failed` or `generating`, the file was never downloaded
4. **Don't show yesterday's scene-contact-sheet images for today's S-class board issue** — entirely different systems

## API Architecture

```
Moyin Creator
  ├─ Standard API → POST https://chuangwei.cyou/api/ai/{screenplay,image,video}
  │                  apiKey in request body (not header)
  ├─ Seedance 2.0 → POST https://memefast.top/alibailian/api/v1/services/aigc/video-generation/video-synthesis
  │                  Authorization: Bearer {apiKey} (header)
  └─ S-class Board → Direct image API call (not through studio-run)
                      Uses submitGridImageRequest → persistReferenceImage("shots")
```

## Source Code Reference
- Repo: `github.com/memecalculate/moyin-creator` (AGPL-3.0, TypeScript, Electron)
- S-class board generation: `handleGenerateGroupGridReference` in compiled `index-BiEM7W1o.js`
- Prompt compiler: `src/packages/ai-core/services/prompt-compiler.ts`
- State: `src/stores/sclass-store.ts`

## Recovery Script Pattern
```python
# Backup original first
shutil.copy2(state_file, state_file + '.backup_TIMESTAMP')

# Fix missing imageUrl
scene['imageUrl'] = f'local-image://scenes/{matched_png}'
scene['imageStatus'] = 'completed'

# Fix S-class grid
group['gridImageUrl'] = f'local-image://shots/{matched_png}'
group['groupGridAsset'] = { ... }  # full asset ref
group['gridGenerationStatus'] = 'completed'
```

## Pitfalls
- **Don't confuse scene-contact-sheet with S-class grid board** — different systems, different data paths
- **Always backup JSON state files before modifying** — Zustand persist middleware can break on malformed JSON
- **Media file timestamps are UTC** — adjust for timezone when matching
- **The `studio_run_tasks.status` field is cosmetic** — the actual result is in `summary_json` and the state files
- **WSL paths**: AppData is under `/mnt/c/Users/...`; D drive is `/mnt/d/`
