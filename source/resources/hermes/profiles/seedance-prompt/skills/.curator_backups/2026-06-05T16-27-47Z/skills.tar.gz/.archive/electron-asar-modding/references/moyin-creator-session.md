# 魔因漫创 (moyin-creator) Session Notes

App: 魔因漫创 (moyin-creator)
Repo: github.com/MemeCalculate/moyin-creator
Install: D:\魔因\moyin-creator\
Asar: D:\魔因\moyin-creator\resources\app.asar

## API Proxy

- Provider: chuangwei.cyou
- Auth: apiKey in request BODY (not Bearer header)
- Image endpoint: `/api/ai/image`
- Task polling: `/api/ai/task/{id}`
- Standard OpenAI path: `/v1/images/generations` (Bearer header)
- The 9-grid (九宫格) generation has a SEPARATE routing path (`submitGridImageRequest`)

## Character Image Generation — 7 Hardcoded "1:1" Locations

All in `out/renderer/assets/index-<hash>.js`:

| # | Function | What changed |
|---|----------|-------------|
| 1 | `prepareCharacterDraftExecution` | `"1:1"` → `"16:9"` |
| 2 | `resolveCharacterPreparedImageExecution` fallback | `"1:1"` → `"16:9"` + `resolution: void 0` → `"2K"` |
| 3 | same — explicitExecution path | `"1:1"` → `"16:9"` |
| 4 | same — runtime task path | `"1:1"` → `"16:9"` + `resolution: void 0` → `"2K"` |
| 5-6 | `buildWardrobeVariationExecution` (two places) | `outfitPromptConfig?.aspectRatio \|\| "1:1"` → `"16:9"` |
| 7 | `executeWardrobeVariationImageGeneration` | `input.execution.aspectRatio \|\| "1:1"` → `"16:9"` |

## Resolution Mapping Fix

`gpt-image-2-reverse` was not in `needsPixelSize` whitelist → API received `"16:9"` as string, ignored it.

Fix: Added to MemeFast adapter so `GPT_IMAGE_2_SIZE_BY_ASPECT_RATIO["16:9"]["2K"]` → `"2048x1152"`.

## Timeout Fix

Three locations had 60s timeout:
1. `submitTimeoutMs = 6e4` (two places) → `18e4` (180s)
2. `setTimeout(() => controller.abort(...), 6e4)` in `submitViaChatCompletions` → `18e4`

## chuangwei.cyou Routing (4 injections)

- Regex: `/chuangwei\.cyou/`
- Endpoint: `/api/ai/image` (in body: `apiKey`)
- Response parse: `data.imageUrl` + `data.taskId`
- Poll: `/api/ai/task/{id}`
- Skip chat-completions fallback for chuangwei

## local-image:// → base64

chuangwei.cyou cannot access `local-image://` URLs. Added `materializeImageSourceToDataUrl` call in `submitGridImageRequest` when proxy is chuangwei and image source is `local-image://`.

## sed Replacements That Worked

```bash
# Context-line match + next-line substitute
sed -i '/prompt: params\.prompt,/{n;s/"1:1"/"16:9"/}' file.js

# Global single-line
sed -i 's/outfitPromptConfig?\.aspectRatio || "1:1"/outfitPromptConfig?.aspectRatio || "16:9"/g' file.js
sed -i 's/resolution: void 0/resolution: "2K"/g' file.js
```

## Key Lesson: Queue Mode vs Direct Mode

The user's character generation used **task queue mode** (studio-run jobs), which goes through `resolveCharacterPreparedImageExecution` → `executePreparedImage` → `submitGridImageRequest`. This is COMPLETELY DIFFERENT from the direct generation path (UI button click → `generateCharacterImage` → `submitImageTask`).

Always search for hardcoded values across the ENTIRE bundle, not just the function you first find.
