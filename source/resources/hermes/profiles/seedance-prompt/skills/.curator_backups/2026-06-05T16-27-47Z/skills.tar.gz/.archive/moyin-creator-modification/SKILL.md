---
name: moyin-creator-modification
description: Modify 魔因漫创 (moyin-creator) Electron app — locate install & project data, extract/patch/repack asar, restart, and use the open-source repo as reference.
---

# 魔因漫创 (moyin-creator) Modification

Modify the compiled Electron app without rebuilding from source. Covers finding app/project locations, extracting and patching the asar bundle, and restarting from WSL.

## Trigger conditions
- User asks to modify 魔因漫创, moyin-creator, or "the app"
- User asks to change code behavior (timeouts, aspect ratios, API routing, prompt building)
- User says "帮我改一下软件里的..."
- Any task that requires `asar extract` / `asar pack` on this specific app

## App & data locations

| What | Windows path | WSL path |
|------|-------------|----------|
| Install dir | `D:\魔因\moyin-creator\` | `/mnt/d/魔因/moyin-creator/` |
| asar bundle | `resources/app.asar` | same |
| Electron user data | `%APPDATA%\Roaming\魔因漫创-profiles\default-58d22b804dd3` | `/mnt/c/Users/Administrator/AppData/Roaming/魔因漫创-profiles/default-58d22b804dd3` |
| runtime DB | `studio-run/runtime.db` (SQLite, tables: `studio_run_tasks`, `studio_run_jobs`) | same |
| **Project data (primary)** | `D:\moyinxiangmu\` | `/mnt/d/moyinxiangmu/` |
| Project dirs | `projects/_p/<project-uuid>/` | same |
| Media files | `media/characters/`, `media/scenes/` | same |

> **IMPORTANT**: The project data is at `D:\moyinxiangmu\`, NOT under the Electron AppData user data directory. When looking for project JSON files (characters.json, sclass.json, scenes.json, director.json), search `D:\moyinxiangmu\projects\_p\<id>\` first.

## Key bundles in the asar

The renderer is Vite-bundled. Key files after extraction:
- `out/renderer/assets/index-BiEM7W1o.js` — **main renderer bundle** (~7.4MB). Contains UI components, image-generator, character panel, grid API, all modifications go here.
- `out/renderer/assets/ai-worker-CNEoMg1t.js` — worker thread (~42KB). Contains image/video generation worker logic.

## Modification workflow

### 1. Extract the asar
```bash
cd /tmp && rm -rf /tmp/asar_mini && mkdir /tmp/asar_mini
npm install asar  # if not installed
./node_modules/.bin/asar extract "/mnt/d/魔因/moyin-creator/resources/app.asar" /tmp/asar_mini/
```
Extraction of the full asar can take 60-120 seconds due to large node_modules.

### 2. Use the open-source repo as reference
The source is at `github.com/MemeCalculate/moyin-creator` (3591 stars). Clone it for reference:
```bash
cd /tmp && git clone --depth 1 https://github.com/MemeCalculate/moyin-creator.git
```
The compiled bundle retains readable variable names and strings — you can search the source for function signatures, then grep the bundle for the same patterns.

### 3. Patch the bundle
Use `patch` tool with `mode='replace'` on the extracted JS file. Always include enough context to ensure uniqueness. Example:
```
old_string: "  const aspectRatio = params.aspectRatio || \"1:1\";"
new_string: "  const aspectRatio = params.aspectRatio || \"16:9\";"
```

### 4. Repack and replace
```bash
# Backup
cp "/mnt/d/魔因/moyin-creator/resources/app.asar" "/mnt/d/魔因/moyin-creator/resources/app.asar.bak_<reason>"

# Repack
cd /tmp && ./node_modules/.bin/asar pack /tmp/asar_mini/ /tmp/app_new.asar

# Replace
cp /tmp/app_new.asar "/mnt/d/魔因/moyin-creator/resources/app.asar"
```

Verify with: `grep 'your_new_string' "/mnt/d/魔因/moyin-creator/resources/app.asar"`

### 5. Restart the app (from WSL)
```bash
taskkill.exe /f /im moyin-creator.exe
powershell.exe -Command "Start-Process 'D:\魔因\moyin-creator\moyin-creator.exe'"
```
Do NOT use `cmd.exe /c start` — it fails with UNC path errors from WSL.

## Finding the correct project

When the user disputes which project is active:
1. **Check runtime.db first**: `SELECT project_id, label, status, created_at FROM studio_run_tasks ORDER BY id DESC LIMIT 10` — the project_id with the most recent/running tasks is the active project.
2. Known projects: `80120cc3` = 修仙界禁止搞军火1, `a4bbe260` = 灌篮少女（演示）.

## Debugging Techniques

### HTTP Ping Injection (for unresponsive buttons)

When a button appears to do nothing (no visual feedback, no error), the first question is: does the onClick handler even fire? Since Electron's renderer can make HTTP requests, inject a ping into the onClick handler:

```js
// BEFORE (in extracted JS):
onClick: () => onGenerateGroupGrid?.(group.id),

// AFTER:
onClick: () => { window.electronAPI?.httpRequest({url:"http://127.0.0.1:9999/ping",method:"GET"}).catch(()=>{}); onGenerateGroupGrid?.(group.id); },
```

Then run a Python HTTP server on port 9999:
```bash
python3 -u -c "
import http.server
class H(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        with open('/tmp/hermes_ping.log','a') as f:
            f.write(f'PING — {self.path}\n')
            f.flush()
        self.send_response(200); self.end_headers(); self.wfile.write(b'ok')
    def log_message(self,*a): pass
http.server.HTTPServer(('0.0.0.0',9999),H).serve_forever()
" &
```

If a ping arrives → onClick fires, problem is inside the handler function. If no ping → button is disabled or handler not connected. Check the `disabled` attribute on the button element.

### Zombie State Detection

After the app crashes or is killed during image generation, `gridGenerationStatus` may stay `"generating"` in sclass.json forever. The app doesn't detect lost tasks on restart.

**Detection**: Check all shotGroups for stuck `"generating"` status with no runtime.db task:
```python
gen = [i for i, sg in enumerate(shot_groups) if sg.get("gridGenerationStatus") == "generating"]
```
If groups have been "generating" for >10 minutes with no change, they're zombies.

**Fix**: Reset the status directly in sclass.json:
```python
sg["gridGenerationStatus"] = "idle"
sg["gridGenerationError"] = None
```
Then restart the app so it reads the clean state.

### Scene 四视图 Missing in Mapping

When generated 四视图 (orthographic views) don't appear in S级 → 场景映射:

1. **Check `imageUrl`**: Generated viewpoint variant scenes may have `referenceImage` set but `imageUrl` empty. Copy `referenceImage` → `imageUrl` and set `imageStatus: "completed"`.
2. **Check `_shared/scenes.json`**: The scene mapping panel draws from the shared store. If it's empty (`"scenes": []`), add the viewpoint variants.

## Pitfalls

- **⚠️ Chuangwei.cyou proxy routing is BROKEN**: The custom `/api/ai/image` endpoint with `apiKey`-in-body auth does NOT work on chuangwei.cyou (returns `"Invalid URL"`). The API uses standard OpenAI-compatible endpoints (`/v1/images/generations`) with Bearer auth. **Remove ALL chuangwei-specific routing code** (the `isChuangweiProxy` branches in `submitGridImageRequest` and `submitViaChatCompletions`). Keep the `local-image://` → base64 conversion but apply it unconditionally (not just for chuangwei), since no API can access Electron's `local-image://` protocol URLs.
- **Four separate timeout locations** (not just one): When increasing timeouts, ALL must be changed. See `references/code-locations.md` for exact line numbers:
  1. `submitViaChatCompletions` AbortController (60s hardcoded, DOMException message)
  2. `submitViaChatCompletions` `fetchWithTimeout$1` timeoutMs parameter
  3. `submitGridImageRequest` `fetchWithTimeout$1` timeoutMs parameter  
  4. Kling `submitViaKlingImages` `fetchWithTimeout$1` (×2 occurrences, use `replace_all`)
  Change ALL to `6e5` (600s) and update the error message to match. Missing any one location causes intermittent "60 seconds" timeouts.
- **⚠️ DUAL CODE PATHS — the #1 pitfall**: Character image generation has TWO completely separate code paths. Modifying only one (the obvious one) means changes silently fail. See `references/dual-code-paths.md` for the full breakdown. Always check runtime.db for `studio_run_tasks` with `category='character-generation'` — if tasks exist, the user IS on the task queue path and `resolveCharacterPreparedImageExecution` (not the generation panel) is where the aspect ratio must be changed.
- **Changing image aspect ratio is a FIVE-STEP fix** (see `references/code-locations.md` for exact code and line numbers):
  1. Task queue path: 3x hardcoded `"1:1"` in `resolveCharacterPreparedImageExecution` + `resolution: void 0` → `"2K"` (**this is where the bug usually lives**)
  2. Direct path: 2x `aspectRatio: "1:1"` in generation-panel.tsx / character-generator.tsx call sites
  3. Default fallback: `params.aspectRatio || "1:1"` in `generateImage`
  4. Pixel-size conversion: add model to `needsPixelSize()` whitelist
  5. MemeFast adapter: register model in BOTH `MEMEFAST_GPT_IMAGE_2_MODELS` Set AND `MEMEFAST_GPT_IMAGE_VARIANTS` map for proper size mapping (2048x1152 vs invalid 1280x720)
- **Always verify the fix by checking actual output image dimensions** with a PNG parser — don't trust the code alone.
- **asar extraction is slow** (60-120s). Use `terminal(background=true, notify_on_complete=true)`.
- **The project data path is custom** (`D:\moyinxiangmu\`). Not in AppData. Check there first.
- **cmd.exe start fails from WSL**. Use `powershell.exe -Command "Start-Process '...'"`.
- **App restart is mandatory** after asar replacement. Process holds old bundle in memory.
- **The renderer bundle name (index-*.js) may change** with app updates. Verify with `asar list`.
- **ASPECT_RATIO_DIMS sizes may not be valid API sizes** (1280x720 is NOT a GPT Image 2 size). Prefer MemeFast adapter which uses GPT_IMAGE_2_SIZE_BY_ASPECT_RATIO (2048x1152 for 16:9@2K).
- **MemeFast adapter needs TWO registrations**: both Set AND map. Missing either → adapter returns null → fallback to standard path.
- **Chuangwei.cyou routing is grid-only**: custom `/api/ai/image` endpoint exists only in `submitGridImageRequest`. Character generation `submitImageTask` uses standard `/v1/images/generations`.
  4. Pixel-size conversion: add model to `needsPixelSize()` whitelist so ratio strings → pixel dimensions
  5. MemeFast adapter: register model in BOTH `MEMEFAST_GPT_IMAGE_2_MODELS` Set AND `MEMEFAST_GPT_IMAGE_VARIANTS` map for proper size mapping (GPT_IMAGE_2_SIZE_BY_ASPECT_RATIO produces valid sizes like 2048x1152, unlike ASPECT_RATIO_DIMS which produces invalid sizes like 1280x720)
- **Always verify the fix by checking actual output image dimensions** with a PNG parser — don't trust the code alone. Use python to read PNG IHDR width/height without PIL.
- **Always verify the fix by checking actual output image dimensions** with a PNG parser — don't trust the code alone. Use python to read PNG IHDR width/height without PIL.
- **ASPECT_RATIO_DIMS sizes may not be valid API sizes**: needsPixelSize uses ASPECT_RATIO_DIMS which produces 1280x720 for 16:9. This is NOT a valid GPT Image 2 API size — the API silently ignores it and uses default dimensions. The MemeFast adapter path uses GPT_IMAGE_2_SIZE_BY_ASPECT_RATIO instead, producing 2048x1152 (2K 16:9) which IS valid. For GPT Image models, registering in the MemeFast adapter is the PREFERRED approach.
- **MemeFast adapter needs TWO registrations**: the model must be added to both MEMEFAST_GPT_IMAGE_2_MODELS Set AND MEMEFAST_GPT_IMAGE_VARIANTS map. Missing either causes the adapter to return null and fall back to the standard path (where ASPECT_RATIO_DIMS kicks in with potentially invalid sizes).
- **Chuangwei.cyou routing is grid-only**: the custom /api/ai/image endpoint and apiKey-in-body auth exists only in submitGridImageRequest. Character generation (submitImageTask) uses standard /v1/images/generations with Bearer auth. Do not add chuangwei routing to character gen path without verifying endpoint support.
