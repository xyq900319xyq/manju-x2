# Chuangwei.cyou API Protocol

## Endpoints

| Operation | Method | URL | Auth |
|-----------|--------|-----|------|
| Submit image | POST | `{baseUrl}/api/ai/image` | `apiKey` in JSON body |
| Poll task | GET | `{baseUrl}/api/ai/task/{taskId}?provider=memefast&type=image&apiKey={key}` | `apiKey` in query string |

## Submit Request Body

```json
{
  "prompt": "string",
  "negativePrompt": "string",
  "aspectRatio": "16:9|9:16|1:1",
  "apiKey": "sk-...",
  "provider": "memefast",
  "referenceImages": ["https://...", "data:image/png;base64,..."]
}
```

**Critical**: `referenceImages` must be URLs the proxy can access — `https://` URLs or `data:` URLs. `local-image://` URLs will silently fail (proxy returns an image but without character references applied).

## Submit Response

```json
{
  "imageUrl": "https://...",     // present when completed immediately
  "taskId": "string",            // present when async — poll for result
  "status": "completed|processing|failed"
}
```

## Poll Response

```json
{
  "status": "completed|processing|failed",
  "result": {
    "url": "https://..."
  },
  "error": "string"
}
```

## Connectivity Test

```bash
# Should return 404 (not connection error) if reachable
curl -s -o /dev/null -w "HTTP %{http_code} | Time: %{time_total}s" \
  --connect-timeout 10 \
  "https://chuangwei.cyou/api/ai/image" \
  -X POST -H "Content-Type: application/json" -d '{"prompt":"test"}'
# Expected: HTTP 404 (endpoint exists, missing auth)
```

## Model Registration

When adding new models to the memefast family, update `MEMEFAST_GPT_IMAGE_2_MODELS` in the renderer bundle to avoid routing to wrong endpoints. Models NOT in this list use standard OpenAI `/v1/images/generations` path — which chuangwei.cyou does not support.
