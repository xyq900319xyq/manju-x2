# chuangwei.cyou 代理 local-image:// 转换修复

## 问题
chuangwei.cyou 代理无法访问 `local-image://` 格式的本地文件 URL，导致角色参考图传入无效。
`submitGridImageRequest` 中 `referenceImages` 参数原样传递 `local-image://` URL 给远程 API。

## 修复位置
`out/renderer/assets/index-BiEM7W1o.js` → `submitGridImageRequest` 函数

在 `retryOperation` 回调中，`fetchUrl` 构建之前插入转换逻辑：

```javascript
const data = await retryOperation(async () => {
    const currentApiKey = keyManager?.getCurrentKey?.() || apiKey;
    if (signal?.aborted) throw createAbortError$1(signal.reason);
    // ====== INSERT START ======
    if (isChuangweiProxy && requestBody.image_urls && requestBody.image_urls.length > 0) {
      const converted = await Promise.all(requestBody.image_urls.map(async (url) => {
        if (url && (url.startsWith("local-image://") || url.startsWith("local-video://"))) {
          try {
            const dataUrl = await materializeImageSourceToDataUrl(url);
            console.log("[GridImageAPI] Converted local ref:", url.substring(0, 40));
            return dataUrl || url;
          } catch(e) {
            console.warn("[GridImageAPI] Failed to convert local ref:", e.message);
            return url;
          }
        }
        return url;
      }));
      requestBody.image_urls = converted;
    }
    // ====== INSERT END ======
    const fetchUrl = isChuangweiProxy ? `${normalizedBase}/api/ai/image` : endpoint;
    // ... 后续代码不变
```

## 原理
- `materializeImageSourceToDataUrl(url)` 是已有函数（行 86847），可将 `local-image://` 转为 `data:image/png;base64,...`
- 底层通过 Electron 的 `window.imageStorage.readAsBase64()` 读取本地文件
- 转换后 chuangwei.cyou 直接收到 base64 数据，无需访问本地文件系统

## 注意事项
- 仅对 `isChuangweiProxy` 路径生效，不影响其他 provider
- 转换失败时保留原始 URL（降级处理，不会阻断请求）
- 大图转换可能较慢，但 180s 超时足够覆盖
