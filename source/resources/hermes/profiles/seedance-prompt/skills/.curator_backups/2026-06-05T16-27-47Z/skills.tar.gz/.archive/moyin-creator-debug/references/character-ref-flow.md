# 角色参考图完整链路

## 数据 → 代码 → API 流程

```
characters.json (primaryImage/views/variations)
    ↓
getCharacterPrimaryImage(char)
  ├── primaryRevision?.imageUrl          (优先)
  ├── views.find("front")?.imageUrl
  ├── thumbnailUrl                        (回退)
  ├── referenceImages[0]
  └── views[0]?.imageUrl
    ↓
collectCharacterRefs(characterIds, characters)
  └── displayUrl = variationReferenceImage || getCharacterPrimaryImage(char)
  └── 若 !imageUrl → 跳过此角色
  └── buildAutoImageRef({url, fileName, purpose: "character_ref"})
    ↓
buildAutoImageRef(params)
  ├── localUrl = params.url.trim()
  └── httpUrl = isRemoteLikeAssetUrl(url) ? url : null
        └── isRemoteLikeAssetUrl: /^https?:\/\//i.test || /^asset:\/\//i.test
    ↓
collectAllRefs(group, scenes, characters, ...)
  ├── collectCharacterRefs → charRefs
  ├── collectSceneRefs → sceneRefs
  ├── collectPropRefs → propRefs
  └── pushUniqueRefs → taggedImages (打 @图片N 标签)
    ↓
返回 {images: taggedImages, videos, audios}
    ↓
执行记录 (127652 / 128592 行):
  referenceImages: promptResult.refs.images.map(ref => ref.httpUrl || ref.localUrl).filter(Boolean)
    ↓
submitGridImageRequest({referenceImages, ...})
  ├── chuangwei 检测 → /chuangwei\.cyou/i.test(normalizedBase)
  ├── isChuangweiProxy ? POST /api/ai/image (apiKey in body, provider: "memefast")
  └── 非 chuangwei → 标准路径（Bearer header）
```

## 关键函数位置 (index-BiEM7W1o.js)

| 函数 | 行号 | 作用 |
|------|------|------|
| `getCharacterPrimaryImage` | 31807 | 获取角色主图 URL |
| `buildAutoImageRef` | 105512 | 构建图片引用对象 |
| `isRemoteLikeAssetUrl` | 105508 | 判断 URL 是否远程（仅认 http(s)/asset） |
| `collectCharacterRefs` | 105982 | 收集角色参考图 |
| `collectAllRefs` | 106108 | 汇总所有参考 |
| `submitGridImageRequest` | ~85404 | 发送九宫格 API 请求 |
| `generateStoryboardImage` | 100920 | 分镜图生成入口 |
| `buildStoryboardPrompt` | 100780 | 构建分镜 Prompt |
| `materializeImageSourceToDataUrl` | 86847 | local-image:// → base64 data URL 转换 |
| `readImageAsBase64` | 25570 | 通过 IPC 读取本地图片为 base64 |

## state 字段说明

### sclass.json - shotGroups[]
- `gridGenerationStatus`: idle | generating | completed | failed
- `gridGenerationError`: 错误信息
- `gridImageUrl`: 生成的九宫格图 URL
- `characterReferenceImages`: 角色参考（通常为空）
- `imageRefs`: 手动添加的图片参考

### scenes.json - scenes[]
- `characterIds`: 关联的角色 ID 数组（通常为空 → 角色不进 prompt）
- `imageUrl`: 场景图 URL
- `contactSheetUrl`: 联系表 URL
- `parentSceneId`: 父场景 ID

### characters.json - characters[]
- `primaryImage`: 主定妆照（通常为空）
- `views[]`: 视图列表（front/side/back）
- `variations[]`: 角色变体（每个有 referenceImage）
- `thumbnailUrl`: 缩略图
