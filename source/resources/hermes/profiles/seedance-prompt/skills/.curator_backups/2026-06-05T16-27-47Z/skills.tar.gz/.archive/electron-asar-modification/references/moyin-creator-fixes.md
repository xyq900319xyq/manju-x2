# 魔因漫创 (moyin-creator) Fixes

## Environment
- App: 魔因漫创 (Electron), located at `D:\魔因\moyin-creator\`
- asar: `resources/app.asar`
- Main JS bundle: `out/renderer/assets/index-XXXXXX.js` (~7.4MB minified)
- Data: `D:\moyinxiangmu\projects\_p\<project-id>\`
- Media: `D:\moyinxiangmu\media\` (subdirs: characters/, scenes/, shots/)

## Fix 1: Chuangwei Proxy Routing (WRONG)
**Problem**: Code added custom routing for chuangwei.cyou that used `/api/ai/image` endpoint with `apiKey` in body. This endpoint DOES NOT EXIST — returns `"Invalid URL"`.

**Fix**: Remove all chuangwei-specific routing. Use standard OpenAI endpoints:
- Endpoint: Standard `${rootBase}${imagePaths.submit}` (typically `/v1/images/generations`)
- Auth: `Authorization: Bearer <key>` header
- Body: Standard OpenAI format `{model, prompt, n, aspect_ratio, ...}`

**Files affected**:
- `submitGridImageRequest` (~line 85509-85585): Remove `isChuangweiProxy` detection, `/api/ai/image` endpoint, custom body format, custom polling
- Keep local-image→base64 conversion for ALL requests (not just chuangwei)

## Fix 2: Local-Image → Base64 Conversion
**Problem**: Character/scene reference images use `local-image://` URLs that remote APIs can't access.

**Fix**: Before `compressReferenceImage()` in both `submitGridImageRequest` AND `submitViaChatCompletions`, add:
```js
const resolvedRefs = await Promise.all(referenceImages.map(async (img) => {
    if (typeof img === "string" && (img.startsWith("local-image://") || img.startsWith("local-video://"))) {
        try {
            const dataUrl = await materializeImageSourceToDataUrl(img);
            if (dataUrl) return dataUrl;
        } catch(e) {}
    }
    return img;
}));
```

## Fix 3: Timeout Values
**Problem**: Multiple hardcoded timeouts at 60s (6e4) caused premature failures.

**All locations and changes**:
1. `submitViaChatCompletions` AbortController: `6e4` → `6e5` (600s), error message "60 seconds" → "600 seconds"
2. `submitGridImageRequest` line 85222: `isMemefastGptImage2Model ? 12e4 : 18e4` → `6e5`
3. `submitGridImageRequest` line 85507: same as above
4. Kling path `fetchWithTimeout$1`: `6e4` → `6e5`

## Fix 4: Aspect Ratio 16:9
**Problem**: 7 locations hardcoded `"1:1"` aspect ratio for character image generation.

**Locations** (in `index-XXXXXX.js`):
- `prepareCharacterDraftExecution`: `aspectRatio: "1:1"` → `"16:9"`
- `resolveCharacterPreparedImageExecution` (3 places): `"1:1"` → `"16:9"`, `resolution: void 0` → `"2K"`
- `outfitPromptConfig` fallback (2 places): `"1:1"` → `"16:9"`
- `wardrobe variation execution`: `"1:1"` → `"16:9"`

## Fix 5: Character Reference Images Missing
**Problem**: Characters had `primaryImage: None` — the grid generation uses this field to collect reference images. Without it, 0 character references are sent to the API.

**Fix**: Set `primaryImage` in `characters.json` to the character's `thumbnailUrl`:
```json
{"primaryImage": "local-image://characters/1779351076861_156jld.png"}
```

## Key File Paths
- App: `D:\魔因\moyin-creator\resources\app.asar`
- Project data: `D:\moyinxiangmu\projects\_p\<project-id>\`
  - `sclass.json` — storyboard state (shotGroups, splitScenes, gridGenerationStatus)
  - `scenes.json` — scene library with viewpoint variants
  - `characters.json` — character data with primaryImage
  - `media.json` — media file registry
  - `runtime.db` — SQLite task history
- Shared data: `D:\moyinxiangmu\projects\_shared\scenes.json`
- Media files: `D:\moyinxiangmu\media\{characters,scenes,shots}\`

## State Reset Pattern
When groups get stuck in `generating` or `failed` status, reset them before restarting:
```python
for sg in data["state"]["projectData"]["shotGroups"]:
    if sg.get("gridGenerationStatus") in ("generating", "failed"):
        sg["gridGenerationStatus"] = "idle"
        sg["gridGenerationError"] = None
```
